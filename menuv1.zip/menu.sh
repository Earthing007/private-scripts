#!/bin/bash

echo "Create_User
Delete_User
Show_Users
Show_Ports
Change_Ports
Speedtest
Remove_Script
Exit_Menu" > /tmp/options.menu

clear
echo ""
echo "MAIN MENU"
echo ""

PS3="Enter the number corresponding to the options: "

select OPT in `cat /tmp/options.menu`
do 
	case $OPT in
		Create_User)
			clear
			user_create
			break
			;;
		Delete_User)
			clear
			user_delete
			break
			;;
		Show_Users)
			clear
			user_show
			break
			;;
		Show_Ports)
			clear
			ports_show
			break
			;;
		Change_Ports)
			clear
			ports_change
			break
			;;
		Speedtest)
			clear
			speedtest
			break
			;;
		Remove_Script)
			clear
			ports_show
			break
			;;
		Exit_Menu)
			clear
			ports_show
			break
			;;
		*)
			echo "Error: Please try again"
			sleep 3
			menu
			;;
	esac
done