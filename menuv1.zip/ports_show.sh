#!/bin/bash

source /usr/local/sbin/base

clear
echo ""
echo "PORTS LIST"
echo ""

openssh="$(netstat -ntlp | grep -i ssh | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"
dropbear="$(netstat -nlpt | grep -i dropbear | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"
stunnel4="$(netstat -nlpt | grep -i stunnel4 | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"
squid="$(netstat -nlpt | grep -i squid | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"
openvpn="$(netstat -nlpt | grep -i openvpn | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"
badvpn="$(netstat -nlpt | grep -i badvpn | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"
webmin="$(netstat -nlpt | grep -i perl | awk '{print $4}' | cut -d: -f2 | xargs | sed 's/ /, /g')"

echo " OpenSSH Port: "$openssh
echo " Dropbear Port: "$dropbear
echo " Stunnel4 Port: "$stunnel4
echo " Squid Proxy Port: "$squid
echo " OpenVPN Port: "$openvpn
echo " Badvpn-udpgw Port: "$badvpn
echo " Webmin Port: "$webmin
echo -e "\n"
return