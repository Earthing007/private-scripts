#!/bin/bash

source /usr/local/sbin/base

clear
echo ""
echo "DELETE USERS"
echo ""
awk -F : '$3 >= 500 {print $1}' /etc/passwd | grep -v '^nobody' > /tmp/user.db

No_user="$(awk -F : '$3 >= 500 {print $1}' /etc/passwd | grep -v '^nobody' | wc -l)"

_delete_one ()
{
	clear
	PS3="Enter the number corresponding to the user: "

	select USER in `cat /tmp/user.db`
	do
		userdel -f $USER
		rm -rf /home/$USER
		echo ""
		echo " User Deleted!"
		echo -e "\n"
		return
		break
	done
}

_delete_all ()
{
	cat /tmp/user.db | while read USER
	do
			echo "Deleting: $USER"
			userdel -f $USER
			rm -rf /home/$USER
	done

	echo ""
	echo " Users Deleted!"
	echo -e "\n"
	return
}


PS3="Choose the numer from options: "

select option in Delete_One Delete_All Exit;
do
	case $option in
		Delete_One)
			if [[ $No_user -eq 0 ]]; then
				echo ""
				echo -e "No user to delete. \n" && return
			else
				_delete_one
			fi
			break
			;;
		Delete_All)
			if [[ $No_user -eq 0 ]]; then
				echo ""
				echo -e "No user to delete. \n" && return
			else
				_delete_all
			fi
			break
			;;
		Exit)
			return
			break
			;;
		*)
			echo "Please make a selection from the provided options."
	esac
done

