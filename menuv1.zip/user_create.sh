#!/bin/bash

source /usr/local/sbin/base

clear
echo ""
echo "CREATE USERS"
echo ""
echo -e "Enter details \n"
read -p $' Username: ' User
# Check If Username Exist, Else Proceed
cat < /etc/passwd | cut -d: -f1 | grep -x -E "^${User}" >/dev/null
if [ $? -eq 0 ]; then
	clear
	echo ""
	echo " Username already taken, please try another or delete existing first."
	sleep 3
	user_create
else
	read -p $' Password: ' Pass
	read -p $' How many days: ' Days
	echo ""
	clear
	sleep 1

	IPADDR=$(wget -4qO- http://ipinfo.io/ip)
	Today=`date +%s`
	Days_Detailed=$(( $Days * 86400 ))
	Expire_On=$(($Today + $Days_Detailed))
	Expiration=$(date -u --date="1970-01-01 $Expire_On sec GMT" +%Y/%m/%d)
	Expiration_Display=$(date -u --date="1970-01-01 $Expire_On sec GMT" '+%b %d %Y')

	useradd -m -s /bin/false -e $Expiration $User > /dev/null
	cat < /etc/passwd | cut -d: -f1 | grep -x -E "^${User}" &> /dev/null
	echo -e "$Pass\n$Pass\n" | passwd $User &> /dev/null

	echo ""
	echo -e " Account Created! \n"
	echo " Host/IP: "$IPADDR
	echo " Username: "$User
	echo " Password: "$Pass
	echo " Expires on: "$Expiration_Display
	echo -e "\n"
	return
fi