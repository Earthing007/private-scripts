#/bin/bash

speedtest