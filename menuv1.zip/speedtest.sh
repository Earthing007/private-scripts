#/bin/bash

speedtest