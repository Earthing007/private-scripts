#!/bin/bash

return ()
{
	echo ""
	echo "1) Return to main menu"
	echo "2) Exit/Cancel"
	echo ""
	read -p "choose from options --> " return
	clear
	case $return in
		1)
		menu
		;;
		2)
		clear
		exit
		;;
	esac
}