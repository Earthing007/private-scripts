#!/bin/bash

source /usr/local/sbin/base

clear
echo ""
echo "LIST OF USERS"
echo ""

No_user="$(awk -F : '$3 >= 500 {print $1}' /etc/passwd | grep -v '^nobody' | wc -l)"

echo "Total number of users: $No_user"
echo ""

while read list
do
	UIDN=500
	Account="$(echo $list | cut -d: -f1)"
	ID="$(echo $list | grep -v nobody | cut -d: -f3)"
	Exp="$(chage -l $Account | grep "Account expires" | awk -F": " '{print $2}')"
	if [[ $ID -ge $UIDN ]]; then
		echo -e "User: $Account" 
		echo -e "Expiry date: $Exp"
		echo ""
	fi
done < /etc/passwd
return
